import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, classification_report
import pickle
import os

def create_model_directory():
    if not os.path.exists('saved_models'):
        os.makedirs('saved_models')

def train_diabetes_model():
    """Train diabetes prediction model using Pima Indians Diabetes Database"""
    # Load diabetes dataset
    diabetes_data = pd.read_csv('datasets/diabetes.csv')
    
    X = diabetes_data.drop('Outcome', axis=1)
    y = diabetes_data['Outcome']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Save model and scaler
    pickle.dump(model, open('saved_models/diabetes_model.pkl', 'wb'))
    pickle.dump(scaler, open('saved_models/diabetes_scaler.pkl', 'wb'))
    
    # Print model performance
    y_pred = model.predict(X_test_scaled)
    print("Diabetes Model Performance:")
    print(classification_report(y_test, y_pred))

def train_parkinsons_model():
    """Train Parkinson's disease prediction model"""
    # Load Parkinson's dataset
    parkinsons_data = pd.read_csv('datasets/parkinsons.csv')
    
    X = parkinsons_data.drop(['status', 'name'], axis=1)
    y = parkinsons_data['status']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = XGBClassifier(random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Save model and scaler
    pickle.dump(model, open('saved_models/parkinsons_model.pkl', 'wb'))
    pickle.dump(scaler, open('saved_models/parkinsons_scaler.pkl', 'wb'))
    
    # Print model performance
    y_pred = model.predict(X_test_scaled)
    print("\nParkinson's Model Performance:")
    print(classification_report(y_test, y_pred))

def train_lung_cancer_model():
    """Train lung cancer prediction model"""
    # Load lung cancer dataset
    cancer_data = pd.read_csv('datasets/lung_cancer.csv')
    
    X = cancer_data.drop('LUNG_CANCER', axis=1)
    y = cancer_data['LUNG_CANCER']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = SVC(probability=True, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Save model and scaler
    pickle.dump(model, open('saved_models/lung_cancer_model.pkl', 'wb'))
    pickle.dump(scaler, open('saved_models/lung_cancer_scaler.pkl', 'wb'))
    
    # Print model performance
    y_pred = model.predict(X_test_scaled)
    print("\nLung Cancer Model Performance:")
    print(classification_report(y_test, y_pred))

def train_thyroid_model():
    """Train thyroid disorder prediction model"""
    # Load thyroid dataset
    thyroid_data = pd.read_csv('datasets/thyroid.csv')
    
    X = thyroid_data.drop('target', axis=1)
    y = thyroid_data['target']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = XGBClassifier(random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Save model and scaler
    pickle.dump(model, open('saved_models/thyroid_model.pkl', 'wb'))
    pickle.dump(scaler, open('saved_models/thyroid_scaler.pkl', 'wb'))
    
    # Print model performance
    y_pred = model.predict(X_test_scaled)
    print("\nThyroid Model Performance:")
    print(classification_report(y_test, y_pred))

if __name__ == "__main__":
    create_model_directory()
    train_diabetes_model()
    train_parkinsons_model()
    train_lung_cancer_model()
    train_thyroid_model() 