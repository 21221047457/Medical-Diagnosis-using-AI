import pandas as pd
import numpy as np
import os

def create_datasets_directory():
    if not os.path.exists('datasets'):
        os.makedirs('datasets')

def create_diabetes_dataset():
    """Create a sample diabetes dataset based on the Pima Indians Diabetes Database"""
    data = {
        'Pregnancies': np.random.randint(0, 17, 1000),
        'Glucose': np.random.randint(0, 200, 1000),
        'BloodPressure': np.random.randint(0, 122, 1000),
        'SkinThickness': np.random.randint(0, 99, 1000),
        'Insulin': np.random.randint(0, 846, 1000),
        'BMI': np.random.uniform(0, 67.1, 1000),
        'DiabetesPedigreeFunction': np.random.uniform(0.078, 2.42, 1000),
        'Age': np.random.randint(21, 81, 1000)
    }
    
    # Generate target variable based on features
    df = pd.DataFrame(data)
    df['Outcome'] = (df['Glucose'] > 140) & (df['BMI'] > 30)
    df['Outcome'] = df['Outcome'].astype(int)
    
    df.to_csv('datasets/diabetes.csv', index=False)

def create_parkinsons_dataset():
    """Create a sample Parkinson's disease dataset"""
    n_samples = 1000
    data = {
        'name': [f'subject_{i}' for i in range(n_samples)],
        'MDVP:Fo(Hz)': np.random.uniform(80, 260, n_samples),
        'MDVP:Fhi(Hz)': np.random.uniform(100, 500, n_samples),
        'MDVP:Flo(Hz)': np.random.uniform(50, 200, n_samples),
        'MDVP:Jitter(%)': np.random.uniform(0, 1, n_samples),
        'MDVP:Shimmer': np.random.uniform(0, 1, n_samples),
        'NHR': np.random.uniform(0, 1, n_samples),
        'HNR': np.random.uniform(0, 50, n_samples),
        'RPDE': np.random.uniform(0, 1, n_samples),
        'DFA': np.random.uniform(0, 1, n_samples),
        'spread1': np.random.uniform(-10, 10, n_samples)
    }
    
    df = pd.DataFrame(data)
    # Generate target based on features
    df['status'] = ((df['MDVP:Jitter(%)'] > 0.5) & 
                   (df['MDVP:Shimmer'] > 0.5) & 
                   (df['NHR'] > 0.5)).astype(int)
    
    df.to_csv('datasets/parkinsons.csv', index=False)

def create_lung_cancer_dataset():
    """Create a sample lung cancer dataset"""
    n_samples = 1000
    data = {
        'AGE': np.random.randint(20, 90, n_samples),
        'SMOKING': np.random.randint(0, 3, n_samples),  # 0: Never, 1: Former, 2: Current
        'YELLOW_FINGERS': np.random.randint(0, 2, n_samples),
        'ANXIETY': np.random.randint(0, 2, n_samples),
        'PEER_PRESSURE': np.random.randint(0, 2, n_samples),
        'CHRONIC_DISEASE': np.random.randint(0, 2, n_samples),
        'FATIGUE': np.random.randint(0, 2, n_samples),
        'ALLERGY': np.random.randint(0, 2, n_samples),
        'WHEEZING': np.random.randint(0, 2, n_samples),
        'ALCOHOL_CONSUMING': np.random.randint(0, 2, n_samples)
    }
    
    df = pd.DataFrame(data)
    # Generate target based on risk factors
    risk_score = (df['SMOKING'] * 2 + 
                 df['YELLOW_FINGERS'] + 
                 df['WHEEZING'] * 1.5 + 
                 df['CHRONIC_DISEASE'])
    df['LUNG_CANCER'] = (risk_score > 4).astype(int)
    
    df.to_csv('datasets/lung_cancer.csv', index=False)

def create_thyroid_dataset():
    """Create a sample thyroid disorder dataset"""
    n_samples = 1000
    data = {
        'T3': np.random.uniform(0.5, 6.0, n_samples),
        'T4': np.random.uniform(5.0, 20.0, n_samples),
        'TSH': np.random.uniform(0.4, 10.0, n_samples),
        'Age': np.random.randint(18, 90, n_samples),
        'Gender': np.random.randint(0, 2, n_samples)  # 0: Female, 1: Male
    }
    
    df = pd.DataFrame(data)
    # Generate target based on thyroid hormone levels
    df['target'] = ((df['T3'] > 4.0) | 
                   (df['T4'] > 15.0) | 
                   (df['TSH'] > 5.0)).astype(int)
    
    df.to_csv('datasets/thyroid.csv', index=False)

if __name__ == "__main__":
    create_datasets_directory()
    create_diabetes_dataset()
    create_parkinsons_dataset()
    create_lung_cancer_dataset()
    create_thyroid_dataset()