import numpy as np
import pandas as pd
import pickle
import os

def load_model(model_path):
    """
    Load a trained model from the specified path
    """
    try:
        model = pickle.load(open(model_path, 'rb'))
        return model
    except:
        return None

def preprocess_input(data, scaler_path=None):
    """
    Preprocess input data using numpy operations
    """
    if scaler_path and os.path.exists(scaler_path):
        scaler = pickle.load(open(scaler_path, 'rb'))
        return scaler.transform(data)
    else:
        # Simple standardization without sklearn
        mean = np.mean(data, axis=0)
        std = np.std(data, axis=0)
        std[std == 0] = 1  # Avoid division by zero
        return (data - mean) / std

def format_prediction(prediction, prediction_proba=None):
    """
    Format model predictions into human-readable results
    """
    result = {
        'prediction': bool(prediction[0]),
        'confidence': float(prediction_proba[0][1]) if prediction_proba is not None else None,
        'timestamp': pd.Timestamp.now()
    }
    return result

def validate_input(data, required_features):
    """
    Validate that all required features are present in the input data
    """
    missing_features = [feat for feat in required_features if feat not in data]
    if missing_features:
        raise ValueError(f"Missing required features: {missing_features}")
    return True

def generate_report(patient_data, prediction_result):
    """
    Generate a detailed medical report based on the prediction results
    """
    report = {
        'timestamp': prediction_result['timestamp'],
        'prediction': prediction_result['prediction'],
        'confidence': prediction_result['confidence'],
        'input_parameters': patient_data,
        'recommendations': get_recommendations(prediction_result)
    }
    return report

def get_recommendations(prediction_result):
    """
    Generate recommendations based on prediction results
    """
    if prediction_result['confidence'] is None:
        return "Unable to determine confidence level. Please consult with a healthcare professional."
    
    confidence = prediction_result['confidence']
    if confidence < 0.3:
        return "Low Risk: Continue regular health monitoring and maintain healthy lifestyle."
    elif confidence < 0.7:
        return "Moderate Risk: Schedule a follow-up appointment for detailed examination."
    else:
        return "High Risk: Immediate medical consultation recommended." 