# Medical Diagnosis AI System

An AI-powered diagnostic tool that helps healthcare professionals in the early detection of various medical conditions including:
- Diabetes
- Thyroid Disorders
- Lung Cancer
- Parkinson's Disease

## Features

- User-friendly Streamlit interface
- Multiple disease prediction capabilities
- Real-time analysis of patient data
- Interactive visualization of results
- Secure and privacy-focused design

## Installation

1. Clone this repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

Run the Streamlit application:
```bash
streamlit run app.py
```

## Models

The system uses machine learning models trained on verified medical datasets:
- Diabetes: Random Forest Classifier
- Thyroid: Gradient Boosting Classifier
- Lung Cancer: Support Vector Machine (SVM)
- Parkinson's: XGBoost Classifier

## Data Privacy

This application is designed with patient privacy in mind. No data is stored or transmitted externally.

## Disclaimer

This tool is intended to assist healthcare professionals and should not be used as a replacement for professional medical diagnosis. Always consult with qualified medical practitioners for proper diagnosis and treatment. 