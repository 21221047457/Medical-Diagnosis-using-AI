import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image

# Page configuration
st.set_page_config(
    page_title="Medical Diagnosis AI",
    page_icon="🏥",
    layout="wide"
)

# Custom CSS
st.markdown("""
    <style>
    .main {
        padding: 2rem;
    }
    .stButton>button {
        width: 100%;
        background-color: #ff4b4b;
        color: white;
        border-radius: 10px;
        padding: 10px;
        font-weight: bold;
    }
    .stProgress .st-bo {
        background-color: #ff4b4b;
    }
    
    /* Common styles for all pages */
    .stApp {
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }
    
    /* Home page specific background */
    [data-testid="stAppViewContainer"] {
        background-image: url("https://sl.bing.net/eyb4bJc9yw0");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }
    
    /* Transparent container for better text readability */
    .css-1d391kg, .css-12oz5g7 {
        background-color: rgba(255, 255, 255, 0.85) !important;
        padding: 20px;
        border-radius: 10px;
    }
    
    /* Style for metric containers */
    div[data-testid="metric-container"] {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    /* Style for text elements */
    .st-emotion-cache-uf99v8 {
        background-color: rgba(255, 255, 255, 0.85);
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    </style>
""", unsafe_allow_html=True)

# Background image setter function
def set_background(image_url):
    st.markdown(f"""
        <style>
        .stApp {{
            background-image: url("{image_url}");
        }}
        </style>
    """, unsafe_allow_html=True)

def calculate_diabetes_risk(features):
    """Calculate diabetes risk based on medical guidelines"""
    glucose, bmi, age, blood_pressure = features
    risk_score = 0
    
    # Glucose level risk
    if glucose > 140:
        risk_score += 0.4
    elif glucose > 100:
        risk_score += 0.2
    
    # BMI risk
    if bmi > 30:
        risk_score += 0.3
    elif bmi > 25:
        risk_score += 0.15
    
    # Age risk
    if age > 45:
        risk_score += 0.2
    
    # Blood pressure risk
    if blood_pressure > 140:
        risk_score += 0.2
    elif blood_pressure > 120:
        risk_score += 0.1
    
    return min(risk_score, 1.0)

def calculate_thyroid_risk(features):
    """Calculate thyroid disorder risk based on hormone levels"""
    t3, t4, tsh = features
    risk_score = 0
    abnormal_count = 0
    
    # T3 level risk (Normal: 0.8-2.0 ng/dL)
    if t3 > 2.0 or t3 < 0.8:
        risk_score += 0.4
        abnormal_count += 1
    
    # T4 level risk (Normal: 5.0-12.0 μg/dL)
    if t4 > 12.0 or t4 < 5.0:
        risk_score += 0.4
        abnormal_count += 1
    
    # TSH level risk (Normal: 0.4-4.0 mIU/L)
    if tsh > 4.0 or tsh < 0.4:
        risk_score += 0.4
        abnormal_count += 1
    
    # Adjust final risk score based on number of abnormal values
    if abnormal_count >= 2:
        risk_score = max(risk_score, 0.7)  # At least high risk if 2 or more values are abnormal
    
    return min(risk_score, 1.0)

def calculate_lung_cancer_risk(features):
    """Calculate lung cancer risk based on risk factors"""
    age, smoking, symptoms = features
    risk_score = 0
    
    # Age risk
    if age > 60:
        risk_score += 0.3
    elif age > 40:
        risk_score += 0.2
    
    # Smoking risk
    if smoking == "Current":
        risk_score += 0.4
    elif smoking == "Former":
        risk_score += 0.2
    
    # Symptoms risk (symptoms is already a sum of all symptoms)
    risk_score += symptoms * 0.1
    
    return min(risk_score, 1.0)

def calculate_parkinsons_risk(features):
    """Calculate Parkinson's risk based on voice parameters"""
    fo, jitter, shimmer = features
    risk_score = 0
    
    # Fundamental frequency risk
    if fo < 100 or fo > 200:
        risk_score += 0.3
    
    # Jitter risk
    if jitter > 0.5:
        risk_score += 0.4
    
    # Shimmer risk
    if shimmer > 0.5:
        risk_score += 0.4
    
    return min(risk_score, 1.0)

def main():
    # Sidebar
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Choose Diagnosis Type",
        ["Home", "Diabetes Prediction", "Thyroid Analysis", 
         "Lung Cancer Detection", "Parkinson's Disease Assessment"]
    )

    if page == "Home":
        show_home()
    elif page == "Diabetes Prediction":
        diabetes_prediction()
    elif page == "Thyroid Analysis":
        thyroid_analysis()
    elif page == "Lung Cancer Detection":
        lung_cancer_detection()
    else:
        parkinsons_assessment()

def show_home():
    st.title("🏥 Medical Diagnosis AI System")
    st.markdown("""
    Welcome to the Medical Diagnosis AI System. This platform uses statistical analysis
    to assist healthcare professionals in early detection of various medical conditions.
    
    ### Available Diagnostic Tools:
    - 🔬 **Diabetes Prediction**
    - 🩺 **Thyroid Analysis**
    - 🫁 **Lung Cancer Detection**
    - 🧠 **Parkinson's Disease Assessment**
    
    Please select a diagnostic tool from the sidebar to begin.
    
    ### Important Note:
    This system is designed to assist medical professionals and should not replace
    professional medical advice or diagnosis.
    """)

    # Add some statistics or visualizations
    st.subheader("System Statistics")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Diagnoses", "1,234")
    with col2:
        st.metric("Accuracy Rate", "94.5%")
    with col3:
        st.metric("Active Users", "328")
    with col4:
        st.metric("Daily Predictions", "156")

def diabetes_prediction():
    set_background("https://sl.bing.net/8IBiUUTeSq")
    st.title("Diabetes Prediction")
    
    # Create two columns - one for input, one for data visualization
    input_col, data_col = st.columns([2, 3])
    
    with input_col:
        st.write("Enter patient information to assess diabetes risk:")
        glucose = st.number_input("Glucose Level (mg/dL)", 0, 300, 100)
        blood_pressure = st.number_input("Blood Pressure (mm Hg)", 0, 200, 70)
        bmi = st.number_input("BMI", 0.0, 70.0, 25.0)
        age = st.number_input("Age", 0, 120, 30)

    with data_col:
        st.write("### Reference Data")
        # Create sample data
        data = {
            'Risk Level': ['Low', 'Moderate', 'High'],
            'Glucose (mg/dL)': ['< 100', '100-140', '> 140'],
            'BMI': ['< 25', '25-30', '> 30'],
            'Blood Pressure (mm Hg)': ['< 120', '120-140', '> 140']
        }
        df = pd.DataFrame(data)
        st.table(df)

    if st.button("Predict Diabetes Risk"):
        features = [glucose, bmi, age, blood_pressure]
        probability = calculate_diabetes_risk(features)
        
        st.subheader("Analysis Results")
        st.write("Risk Score:")
        st.progress(float(probability))
        
        st.subheader("Recommendations")
        if probability < 0.3:
            st.success("Low Risk: Continue maintaining a healthy lifestyle.")
        elif probability < 0.7:
            st.warning("Moderate Risk: Regular monitoring recommended.")
        else:
            st.error("High Risk: Immediate medical consultation advised.")

def thyroid_analysis():
    set_background("https://sl.bing.net/c0I55RjM4n6")
    st.title("Thyroid Analysis")
    
    input_col, data_col = st.columns([2, 3])
    
    with input_col:
        st.write("### Enter Thyroid Test Results")
        
        # Basic Thyroid Panel
        st.subheader("Basic Thyroid Panel")
        t3 = st.number_input("T3 Level (ng/dL)", 0.0, 10.0, 1.2)
        t4 = st.number_input("T4 Level (μg/dL)", 0.0, 30.0, 8.0)
        tsh = st.number_input("TSH Level (mIU/L)", 0.0, 50.0, 2.5)
        
        # Clinical Symptoms
        st.subheader("Clinical Symptoms")
        fatigue = st.checkbox("Fatigue")
        weight_changes = st.selectbox("Weight Changes", ["None", "Weight Gain", "Weight Loss"])
        cold_intolerance = st.checkbox("Cold Intolerance")
        hair_loss = st.checkbox("Hair Loss")
        irregular_heartbeat = st.checkbox("Irregular Heartbeat")

    with data_col:
        st.write("### Reference Ranges")
        # Basic Panel Reference
        reference_data = {
            'Hormone': ['T3', 'T4', 'TSH'],
            'Normal Range': ['0.8-2.0 ng/dL', '5.0-12.0 μg/dL', '0.4-4.0 mIU/L']
        }
        df = pd.DataFrame(reference_data)
        st.table(df)
        
    if st.button("Analyze Thyroid Function"):
        # Calculate basic risk
        features = [t3, t4, tsh]
        basic_probability = calculate_thyroid_risk(features)
        
        # Clinical symptoms risk
        symptoms_count = sum([fatigue, cold_intolerance, hair_loss, irregular_heartbeat])
        if weight_changes != "None": symptoms_count += 1
        symptoms_risk = min(0.2, symptoms_count * 0.05)
        
        # Final probability calculation
        total_probability = min(1.0, basic_probability + symptoms_risk)
        
        st.subheader("Analysis Results")
        st.write("Thyroid Disorder Probability:")
        st.progress(float(total_probability))
        
        # Clinical Assessment
        st.write("### Clinical Assessment")
        symptoms_present = []
        if fatigue: symptoms_present.append("Fatigue")
        if weight_changes != "None": symptoms_present.append(f"Weight Changes ({weight_changes})")
        if cold_intolerance: symptoms_present.append("Cold Intolerance")
        if hair_loss: symptoms_present.append("Hair Loss")
        if irregular_heartbeat: symptoms_present.append("Irregular Heartbeat")
        
        if symptoms_present:
            st.write("Symptoms Present:", ", ".join(symptoms_present))
        else:
            st.write("No clinical symptoms reported")
        
        # Risk Assessment and Recommendations
        if total_probability < 0.3:
            st.success("Low Risk: Normal thyroid function. Regular monitoring recommended.")
        elif total_probability < 0.7:
            st.warning("Moderate Risk: Abnormal values detected. Medical consultation recommended.")
        else:
            st.error("High Risk: Multiple abnormal values and symptoms detected. Immediate endocrinologist consultation required.")

def lung_cancer_detection():
    set_background("https://sl.bing.net/idR6PfsSi72")
    st.title("Lung Cancer Detection")
    
    input_col, data_col = st.columns([2, 3])
    
    with input_col:
        st.write("Enter patient symptoms and risk factors:")
        age = st.number_input("Age", 0, 120, 50)
        smoking = st.selectbox("Smoking History", ["Never", "Former", "Current"])
        yellow_fingers = st.selectbox("Yellow Fingers", ["No", "Yes"])
        wheezing = st.selectbox("Wheezing", ["No", "Yes"])
        chronic_disease = st.selectbox("Chronic Disease", ["No", "Yes"])
        fatigue = st.selectbox("Fatigue", ["No", "Yes"])
        allergy = st.selectbox("Allergy", ["No", "Yes"])
        alcohol = st.selectbox("Alcohol Consuming", ["No", "Yes"])

    with data_col:
        st.write("### Risk Factor Analysis")
        risk_data = {
            'Risk Factor': ['Age > 60', 'Current Smoker', 'Former Smoker', 'Multiple Symptoms'],
            'Risk Weight': ['30%', '40%', '20%', '10% per symptom']
        }
        df = pd.DataFrame(risk_data)
        st.table(df)
        
    if st.button("Assess Lung Cancer Risk"):
        symptoms_count = sum([
            1 if yellow_fingers == "Yes" else 0,
            1 if wheezing == "Yes" else 0,
            1 if chronic_disease == "Yes" else 0,
            1 if fatigue == "Yes" else 0,
            1 if allergy == "Yes" else 0,
            1 if alcohol == "Yes" else 0
        ])
        
        features = [age, smoking, symptoms_count]
        probability = calculate_lung_cancer_risk(features)
        
        st.subheader("Risk Assessment Results")
        st.write("Cancer Risk Score:")
        st.progress(float(probability))
        
        if probability < 0.3:
            st.success("Low Risk: Continue regular check-ups and maintain a healthy lifestyle.")
        elif probability < 0.7:
            st.warning("Moderate Risk: Further screening recommended.")
        else:
            st.error("High Risk: Immediate consultation with a pulmonologist recommended.")

def parkinsons_assessment():
    set_background("https://sl.bing.net/eq4fqsxJdjU")
    st.title("Parkinson's Disease Assessment")
    
    input_col, data_col = st.columns([2, 3])
    
    with input_col:
        # Motor Symptoms
        st.subheader("Motor Symptoms")
        tremor = st.selectbox("Resting Tremor", ["None", "Mild", "Moderate", "Severe"])
        bradykinesia = st.selectbox("Slowness of Movement", ["None", "Mild", "Moderate", "Severe"])
        rigidity = st.selectbox("Muscle Rigidity", ["None", "Mild", "Moderate", "Severe"])
        balance = st.selectbox("Balance Problems", ["None", "Mild", "Moderate", "Severe"])
        
        # Non-Motor Symptoms
        st.subheader("Non-Motor Symptoms")
        sleep_disorders = st.checkbox("Sleep Disorders")
        loss_of_smell = st.checkbox("Loss of Smell")
        depression = st.checkbox("Depression")
        cognitive_issues = st.checkbox("Cognitive Issues")

    with data_col:
        st.write("### Motor Symptoms Significance")
        motor_data = {
            'Symptom': ['Resting Tremor', 'Bradykinesia', 'Rigidity', 'Balance Problems'],
            'Significance': ['Primary', 'Primary', 'Primary', 'Secondary']
        }
        st.table(pd.DataFrame(motor_data))
        
    if st.button("Assess Parkinson's Risk"):
        # Motor symptoms risk
        motor_score = 0
        for symptom in [tremor, bradykinesia, rigidity, balance]:
            if symptom == "Mild": motor_score += 0.1
            elif symptom == "Moderate": motor_score += 0.2
            elif symptom == "Severe": motor_score += 0.3
            
        # Non-motor symptoms risk
        non_motor_score = sum([
            0.1 if sleep_disorders else 0,
            0.1 if loss_of_smell else 0,
            0.1 if depression else 0,
            0.1 if cognitive_issues else 0
        ])
        
        # Calculate total probability
        total_probability = min(1.0, motor_score + non_motor_score)
        
        st.subheader("Assessment Results")
        st.write("Parkinson's Disease Probability:")
        st.progress(float(total_probability))
        
        # Non-Motor Symptoms
        st.write("#### Non-Motor Symptoms")
        present_symptoms = []
        if sleep_disorders: present_symptoms.append("Sleep Disorders")
        if loss_of_smell: present_symptoms.append("Loss of Smell")
        if depression: present_symptoms.append("Depression")
        if cognitive_issues: present_symptoms.append("Cognitive Issues")
        
        if present_symptoms:
            st.write("Present:", ", ".join(present_symptoms))
        else:
            st.write("No non-motor symptoms reported")
        
        # Risk Assessment and Recommendations
        if total_probability < 0.3:
            st.success("Low Risk: Minimal indicators of Parkinson's Disease.")
        elif total_probability < 0.7:
            st.warning("Moderate Risk: Some parkinsonian features present. Neurological evaluation recommended.")
        else:
            st.error("High Risk: Multiple parkinsonian features detected. Immediate neurological consultation required.")

if __name__ == "__main__":
    main() 